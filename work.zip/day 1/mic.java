class mic
{
	public static void main(String args[])
	{	
		int k=78;
		System.out.println("Hello Boi "+k);
		System.out.print("Hello Boi");
	}
}