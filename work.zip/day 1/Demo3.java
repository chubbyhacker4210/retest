public class Demo3
{
	String user;
	public void task2()
	{
		System.out.println("From task2");
	}
	static public void main(String ar[])//----------3
	{
		Demo3 ref=new Demo3();//--------4
		System.out.println("\n"+ref);//--------5
		System.out.println(ref.user);//---------9
		ref.task2();
		ref=new Demo3();//-----------6
		ref.user="rahul";
		System.out.println("\n"+ref);//---------------7
		System.out.println(ref.user);//---------------8
		ref.task2();
	}
}