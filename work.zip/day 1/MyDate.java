import java.util.Scanner;
class MyDate
{
	public static void main(String args[])
	{
		int dd,mm,yy;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the date");
		int date=s.nextInt();	
		System.out.println("enter the month");
		int month=s.nextInt();
		System.out.println("enter the year");
		int year=s.nextInt();
		System.out.println("Date is: "+date+"/"+month+"/"+year);
		
	}
}