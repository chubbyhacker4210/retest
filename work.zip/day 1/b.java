class a
{
	public static void main(String args[])
	{
		System.out.println("for class A");
	}
}
class b
{
	public static void main(String args[])
	{
		a a1=new a();
		a1.main(null );
		c c1=new c();
		c1.main(null);
		System.out.println("for class B");
	}
}
class c
{
	public static void main(String args[])
	{
		System.out.println("for class C");
	}
}